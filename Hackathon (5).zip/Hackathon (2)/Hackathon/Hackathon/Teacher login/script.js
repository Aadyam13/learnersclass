function submitTimeslot() {
    // Add logic to handle time slot submission
    alert("Time slot submitted.");
}

function acceptRequest() {
    // Add logic to handle accepting a request
    alert("Request accepted.");
}

function declineRequest() {
    // Add logic to handle declining a request
    alert("Request declined.");
}

function submitAnswer() {
    // Add logic to handle answering a doubt
    document.getElementById('points').innerText++;
    alert("Answer submitted.");
}

function withdrawPoints() {
    document.getElementById('withdraw').style.display = 'block';
}

function confirmWithdraw() {
    // Add logic to handle point withdrawal
    alert("Points withdrawn.");
}

function endClass() {
    document.getElementById('points').innerText += 30;
    alert("Class completed.");
}
