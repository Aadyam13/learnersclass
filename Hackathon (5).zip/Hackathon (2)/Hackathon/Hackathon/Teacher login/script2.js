let A = document.getElementById('fullname')
console.log(A)